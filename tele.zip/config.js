export const config = {

 //───────────────────────────────

  // ─── 👑 OWNER CONFIG ───────────────────────────

  //───────────────────────────────

 

    OWNER_ID: 1284296702,

    OWNER_USERNAME: "FarGifar",
    OWNER_NAME: "G1F4R",
    OWNER_LINK: "t.me/FarGifar",
    

  

  //───────────────────────────────

  // ─── 🤖 BOT CONFIG ──────────────────────────────

  //───────────────────────────────

  

    BOTNAME: "BOT ORDER AKRAB",

    TOKEN: "7897542293:AAF45e5svQtUEvcdbOM_ynz0P0brglmC9nE",
USE_AUTO_AI: true,
BOTUSERNAME: "BOT ORDER AKRAB",
};
